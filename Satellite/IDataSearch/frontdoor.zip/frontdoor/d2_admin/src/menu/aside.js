// 菜单 侧边栏
export default [
  { path: '/personal', title: '个人中心', icon: 'user-circle' },
  { path: '/index', title: '检索平台', icon: 'home' },
  { path: '/analysis', title: '分析平台', icon: 'bar-chart-o' },
  { path: '/daily', title: '推荐平台', icon: 'star' },
  { path: '/project', title: '项目仓库', icon: 'archive' },
  { path: '/folder', title: '收藏夹', icon: 'suitcase' }
]
